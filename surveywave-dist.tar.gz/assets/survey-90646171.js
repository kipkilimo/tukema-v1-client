import{M as m}from"./vendor-vue-86b105d4.js";import{a as l,c as u}from"./index-71663f0d.js";import{l as p}from"./templates-3cfe2cb6.js";import{c as o}from"./vendor-graphql-e4435811.js";const g=o`
  query GetSurveys(
    $status: [SurveyStatus!]
    $tags: [String!]
    $categories: [String!]
    $organizationId: ID
    $search: String
    $limit: Int
    $offset: Int
    $sortBy: SurveySortField
    $sortOrder: SortDirection
  ) {
    surveys(
      status: $status
      tags: $tags
      categories: $categories
      organizationId: $organizationId
      search: $search
      limit: $limit
      offset: $offset
      sortBy: $sortBy
      sortOrder: $sortOrder
    ) {
      edges {
        node {
          id
          name
          description
          slug
          status
          currentVersion
          responseCount
          totalResponses
          completionRate
          isPublic
          createdAt
          updatedAt
          tags
          categories
          createdBy {
            id
            name
            email
            role
          }
          organizationId
        }
        cursor
      }
      pageInfo {
        hasNextPage
        hasPreviousPage
        startCursor
        endCursor
        totalCount
      }
      totalCount
    }
  }
`,v=o`
  query GetSurvey($id: ID, $slug: String) {
    survey(id: $id, slug: $slug) {
      id
      name
      description
      slug
      status
      currentVersion
      currentVersionObject {
        id
        version
        questions {
          id
          variableName
          label
          type
          choices {
            id
            name
            label
            order
            parentValue
            filter
          }
          required
          requiredMessage
          hint
          appearance
          relevant
          constraint
          constraintMessage
          defaultValue
          order
          skipLogic {
            id
            condition
            value
            action
            targetQuestionId
            targetQuestion {
              id
              label
              variableName
            }
          }
          cascadingSelect {
            parentQuestionId
            parentQuestion {
              id
              label
            }
            filterExpression
          }
          validation {
            min
            max
            minLength
            maxLength
            pattern
            custom
            message
          }
          mediaConfig {
            maxFiles
            maxSizeMB
            acceptedTypes
            required
          }
          calculation
        }
        xlsFormUrl
        deployedAt
        deployedToKobo
        changelog
        isPublished
        publishedAt
        submittedCount
        completionRate
      }
      versions {
        id
        version
        questions {
          id
          variableName
          label
          type
          choices {
            id
            name
            label
            order
            parentValue
            filter
          }
          required
          requiredMessage
          hint
          appearance
          relevant
          constraint
          constraintMessage
          defaultValue
          order
          skipLogic {
            id
            condition
            value
            action
            targetQuestionId
          }
          cascadingSelect {
            parentQuestionId
            filterExpression
          }
          validation {
            min
            max
            minLength
            maxLength
            pattern
            custom
            message
          }
          mediaConfig {
            maxFiles
            maxSizeMB
            acceptedTypes
            required
          }
          calculation
        }
        xlsFormUrl
        deployedAt
        deployedToKobo
        changelog
        isPublished
        publishedAt
        submittedCount
        completionRate
        createdAt
      }
      activeQuestions {
        id
        variableName
        label
        type
        choices {
          id
          name
          label
          order
          parentValue
          filter
        }
        required
        requiredMessage
        hint
        appearance
        relevant
        constraint
        constraintMessage
        defaultValue
        order
        skipLogic {
          id
          condition
          value
          action
          targetQuestionId
        }
        cascadingSelect {
          parentQuestionId
          filterExpression
        }
        validation {
          min
          max
          minLength
          maxLength
          pattern
          custom
          message
        }
        mediaConfig {
          maxFiles
          maxSizeMB
          acceptedTypes
          required
        }
        calculation
      }
      kobo {
        assetId
        deploymentId
        formId
        webhookId
        webhookSecret
        webhookStatus
        endpoint
        lastSyncAt
        lastDeploymentStatus
        lastDeploymentAttempt
        lastError
        xlsFormHash
        deployedVersion
        stats {
          totalSubmissions
          pendingSubmissions
          completedSubmissions
          lastSubmissionAt
          averageCompletionTime
          geoDataCount
          mediaCount
        }
        urls {
          webForm
          singleSubmission
          offline
          preview
          exports
          edit
          manage
          data
          editData
          dashboard
          api
          smartLink
        }
      }
      responseCount
      totalResponses
      completionRate
      averageTimeToComplete
      organizationId
      organization {
        id
        name
      }
      isPublic
      clonedFrom
      clonedFromSurvey {
        id
        name
        slug
      }
      sharedWith {
        id
        name
        email
        role
      }
      permissions {
        owner
        admins
        editors
        reviewers
        collectors
        viewers
        public
        publicView
        publicCollect
      }
      settings {
        allowAnonymous
        allowMultipleResponses
        showProgressBar
        requireLogin
        redirectUrl
        thankYouMessage
        webhookUrl
        notificationEmails
        survey {
          allowBack
          autoSave
          offline
          autosubmit
          limitResponses
          startDate
          endDate
        }
        appearance {
          theme
          primaryColor
          secondaryColor
          logo
          font
          customCss
        }
        validation {
          strict
          allowIncomplete
          requireCaptcha
          maxAttempts
        }
        security {
          encrypt
          requireLogin
          requireSignature
          ipRestriction
        }
        notifications {
          onSubmission
          onCompletion
          onRejection
        }
      }
      webhookConfig {
        url
        secret
        events
        active
        retryConfig {
          maxAttempts
          retryDelayMs
          backoffMultiplier
        }
        timeoutMs
      }
      tags
      categories
      createdBy {
        id
        name
        email
        role
      }
      createdAt
      updatedAt
    }
  }
`,E=o`
  mutation CreateSurvey($input: CreateSurveyInput!) {
    createSurvey(input: $input) {
      id
      name
      description
      slug
      status
      currentVersion
      isPublic
      tags
      categories
      organizationId
      createdAt
      updatedAt
    }
  }
`,y=o`
  mutation UpdateSurvey($id: ID!, $input: UpdateSurveyInput!) {
    updateSurvey(id: $id, input: $input) {
      id
      name
      description
      status
      tags
      categories
      isPublic
      settings {
        allowAnonymous
        allowMultipleResponses
        appearance {
          theme
        }
        requireLogin
        thankYouMessage
      }
      permissions {
        owner
        admins
        editors
        reviewers
        collectors
        viewers
        public
        publicView
        publicCollect
      }
      updatedAt
    }
  }
`,A=o`
  mutation DeleteSurvey($id: ID!, $force: Boolean) {
    deleteSurvey(id: $id, force: $force) {
      success
      deletedCount
      failedIds
      errors
    }
  }
`,V=o`
  mutation CloneSurvey($id: ID!, $name: String, $includeResponses: Boolean) {
    cloneSurvey(id: $id, name: $name, includeResponses: $includeResponses) {
      id
      name
      description
      slug
      status
      createdAt
    }
  }
`,b=o`
  mutation CreateNewVersion($id: ID!, $input: CreateVersionInput!) {
    createNewVersion(id: $id, input: $input) {
      id
      currentVersion
      versions {
        version
        questions {
          id
          variableName
          label
          type
          required
          order
        }
        changelog
        createdAt
      }
      updatedAt
    }
  }
`,C=o`
  mutation ArchiveSurvey($id: ID!) {
    archiveSurvey(id: $id) {
      id
      status
      updatedAt
    }
  }
`,T=o`
  mutation RestoreSurvey($id: ID!) {
    restoreSurvey(id: $id) {
      id
      status
      updatedAt
    }
  }
`;o`
  mutation ShareSurvey($id: ID!, $userIds: [ID!]!, $permissions: [String!]) {
    shareSurvey(id: $id, userIds: $userIds, permissions: $permissions) {
      id
      sharedWith
      permissions {
        owner
        admins
        editors
        reviewers
        collectors
        viewers
        public
        publicView
        publicCollect
      }
      updatedAt
    }
  }
`;o`
  mutation UnshareSurvey($id: ID!, $userIds: [ID!]!) {
    unshareSurvey(id: $id, userIds: $userIds) {
      id
      sharedWith
      updatedAt
    }
  }
`;o`
  mutation UpdateSurveyPermissions(
    $id: ID!
    $userId: ID!
    $permissions: [String!]!
  ) {
    updateSurveyPermissions(
      id: $id
      userId: $userId
      permissions: $permissions
    ) {
      id
      permissions {
        owner
        admins
        editors
        reviewers
        collectors
        viewers
        public
        publicView
        publicCollect
      }
      updatedAt
    }
  }
`;o`
  mutation ConfigureWebhook($surveyId: ID!, $config: WebhookConfigInput!) {
    configureWebhook(surveyId: $surveyId, config: $config) {
      success
      message
      config {
        url
        secret
        events
        active
        retryConfig {
          maxAttempts
          retryDelayMs
          backoffMultiplier
        }
        timeoutMs
      }
    }
  }
`;o`
  mutation TestWebhook($surveyId: ID!, $testPayload: JSON) {
    testWebhook(surveyId: $surveyId, testPayload: $testPayload) {
      success
      message
      statusCode
    }
  }
`;var h=(e=>(e.NAME="NAME",e.CREATED_AT="CREATED_AT",e.UPDATED_AT="UPDATED_AT",e.STATUS="STATUS",e.RESPONSE_COUNT="RESPONSE_COUNT",e.COMPLETION_RATE="COMPLETION_RATE",e))(h||{}),S=(e=>(e.ASC="ASC",e.DESC="DESC",e))(S||{});const I=4,D=20,d=12;function $(e){return e==null||e===0?d:Math.max(I,Math.min(D,e))}function w(e){if(!e)return"CREATED_AT";const r=e.toUpperCase();return r==="CREATEDAT"||r==="CREATED_AT"?"CREATED_AT":r==="UPDATEDAT"||r==="UPDATED_AT"?"UPDATED_AT":r==="NAME"?"NAME":r==="STATUS"?"STATUS":r==="RESPONSECOUNT"||r==="RESPONSE_COUNT"?"RESPONSE_COUNT":r==="COMPLETIONRATE"||r==="COMPLETION_RATE"?"COMPLETION_RATE":"CREATED_AT"}function R(e){return e&&e.toUpperCase()==="ASC"?"ASC":"DESC"}function P(e){return e.status==="PUBLISHED"||e.status==="DEPLOYED"}function x(e){return e.status==="DRAFT"}function N(e){if(!(!e.versions||e.versions.length===0))return e.versions.reduce((r,t)=>r.version>t.version?r:t)}function L(e){return e.activeQuestions?.length||0}function M(e){return e.versions?.reduce((r,t)=>r+(t.questions?.length||0),0)||0}function O(e){return(e.responseCount||0)>0}function U(e){return{DRAFT:"Draft",PUBLISHED:"Published",DEPLOYED:"Deployed",ARCHIVED:"Archived",DELETED:"Deleted"}[e]||e}function F(e){return e.kobo?.urls?.webForm}const Q=m("survey",{state:()=>({surveys:[],currentSurvey:null,templates:[],totalCount:0,hasMore:!1,loading:!1,error:null,pageInfo:null,activeSurveyVersion:-1,localTemplates:[],useLocalTemplatesOnly:!0,currentFilters:{limit:d,offset:0,sortBy:h.CREATED_AT,sortOrder:S.DESC}}),getters:{getSurveysByStatus:e=>r=>e.surveys.filter(t=>t.status===r),publishedSurveys:e=>e.surveys.filter(r=>r.status==="PUBLISHED"||r.status==="DEPLOYED"),draftSurveys:e=>e.surveys.filter(r=>r.status==="DRAFT"),archivedSurveys:e=>e.surveys.filter(r=>r.status==="ARCHIVED"),getSurveysByCategory:e=>r=>e.surveys.filter(t=>t.categories?.includes(r)),getSurveysByTag:e=>r=>e.surveys.filter(t=>t.tags?.includes(r)),surveyCount:e=>e.surveys.length,hasSurveys:e=>e.surveys.length>0,isSurveyPublished:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?P(t):!1},isSurveyDraft:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?x(t):!1},getLatestVersion:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?N(t):null},getQuestionCount:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?L(t):0},getTotalQuestions:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?M(t):0},hasResponses:e=>r=>{const t=e.surveys.find(s=>s.id===r);return t?O(t):!1},formatStatus:()=>e=>U(e),getKoboUrl:e=>r=>{const t=e.surveys.find(s=>s.id===r);if(t)return F(t)},allCategories:e=>{const r=new Set;return e.surveys.forEach(t=>{t.categories?.forEach(s=>r.add(s))}),Array.from(r)},allTags:e=>{const r=new Set;return e.surveys.forEach(t=>{t.tags?.forEach(s=>r.add(s))}),Array.from(r)},getActiveVersionQuestions:e=>e.currentSurvey?e.activeSurveyVersion===-1?[]:e.currentSurvey.versions?.find(t=>t.version===e.activeSurveyVersion)?.questions||[]:[],getActiveVersion:e=>!e.currentSurvey||e.activeSurveyVersion===-1?null:e.currentSurvey.versions?.find(r=>r.version===e.activeSurveyVersion)||null,hasActiveVersion:e=>!e.currentSurvey||e.activeSurveyVersion===-1?!1:e.currentSurvey.versions?.some(r=>r.version===e.activeSurveyVersion)||!1,availableVersions:e=>e.currentSurvey?e.currentSurvey.versions?.map(r=>({...r,isActive:r.version===e.activeSurveyVersion,isCurrent:r.version===e.currentSurvey?.currentVersion}))||[]:[],latestVersionNumber:e=>e.currentSurvey?.versions?.length?Math.max(...e.currentSurvey.versions.map(r=>r.version)):0,isActiveVersionCurrent:e=>!e.currentSurvey||e.activeSurveyVersion===-1?!1:e.activeSurveyVersion===e.currentSurvey.currentVersion,activeVersionQuestionCount:e=>!e.currentSurvey||e.activeSurveyVersion===-1?0:e.currentSurvey.versions?.find(t=>t.version===e.activeSurveyVersion)?.questions?.length||0,getVersionByNumber:e=>r=>e.currentSurvey&&e.currentSurvey.versions?.find(t=>t.version===r)||null},actions:{handleError(e,r){const t=l();console.error("[SurveyStore]",e);const s=e?.graphQLErrors?.[0]?.message||e?.message||r;throw this.error=s,t.show({message:s,type:"error"}),new Error(s)},handleSuccess(e){l().show({message:e,type:"success"})},clearError(){this.error=null},transformLocalTemplate(e){return{id:e.id,name:e.name,description:e.description,slug:e.id,status:"DRAFT",currentVersion:1,versions:[],activeQuestions:e.questions,kobo:{webhookSecret:"",webhookStatus:"INACTIVE",stats:{totalSubmissions:0,pendingSubmissions:0,completedSubmissions:0,geoDataCount:0,mediaCount:0}},tags:e.tags,categories:[e.templateCategory],responseCount:0,totalResponses:0,completionRate:0,createdBy:"system",organizationId:void 0,isPublic:!0,clonedFrom:void 0,sharedWith:[],permissions:{owner:"system",admins:[],editors:[],reviewers:[],collectors:[],viewers:[],public:!0,publicView:!0,publicCollect:!1},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}},initLocalTemplates(){const e=l();try{return this.localTemplates=p.templates?.map(r=>this.transformLocalTemplate(r))||[],console.log(`Loaded ${this.localTemplates.length} local templates`),this.localTemplates}catch(r){return console.error("Failed to initialize local templates:",r),this.error="Failed to load templates",e.show({message:"Failed to load templates",type:"error"}),[]}},getLocalTemplateById(e){return this.localTemplates.length===0&&this.initLocalTemplates(),this.localTemplates.find(r=>r.id===e)},async fetchSurveys(e){this.loading=!0,this.error=null;try{const r={...this.currentFilters,...e},t=$(r.limit);r.limit=t;let s=r.status;s&&!Array.isArray(s)&&(s=[s]);const i=w(r.sortBy),n=R(r.sortOrder),{data:c}=await u.query({query:g,variables:{status:s,tags:r.tags,categories:r.categories,organizationId:r.organizationId,search:r.search,limit:t,offset:r.offset||0,sortBy:i,sortOrder:n},fetchPolicy:"network-only"}),a=c?.surveys;return a&&(this.surveys=a.edges?.map(f=>f.node)||[],this.totalCount=a.totalCount||0,this.hasMore=a.pageInfo?.hasNextPage||!1,this.pageInfo=a.pageInfo||null,this.currentFilters={...r,sortBy:i,sortOrder:n}),a}catch(r){return this.handleError(r,"Failed to fetch surveys")}finally{this.loading=!1}},async loadMoreSurveys(){if(!this.hasMore||this.loading)return;const e=this.currentFilters.limit||d,t=(this.currentFilters.offset||0)+e,s=await this.fetchSurveys({offset:t});if(s&&s.edges){const i=s.edges.map(n=>n.node);this.surveys=[...this.surveys,...i]}},async fetchSurveyById(e){this.loading=!0,this.error=null;try{const{data:r}=await u.query({query:v,variables:{id:e},fetchPolicy:"network-only"});return this.currentSurvey=r?.survey,this.currentSurvey&&this.activeSurveyVersion===-1&&(this.activeSurveyVersion=this.currentSurvey.currentVersion||1),this.currentSurvey}catch(r){return this.handleError(r,"Failed to fetch survey")}finally{this.loading=!1}},async fetchSurveyBySlug(e){this.loading=!0,this.error=null;try{const{data:r}=await u.query({query:v,variables:{slug:e},fetchPolicy:"network-only"});return this.currentSurvey=r?.survey,this.currentSurvey&&this.activeSurveyVersion===-1&&(this.activeSurveyVersion=this.currentSurvey.currentVersion||1),this.currentSurvey}catch(r){return this.handleError(r,"Failed to fetch survey")}finally{this.loading=!1}},async createSurvey(e){this.loading=!0,this.error=null;try{const{data:r}=await u.mutate({mutation:E,variables:{input:e}}),t=r?.createSurvey;return t&&(this.surveys=[t,...this.surveys],this.totalCount++,this.handleSuccess(`Survey "${t.name}" created successfully`),this.currentSurvey=t,this.activeSurveyVersion=t.currentVersion||1),t}catch(r){return this.handleError(r,"Failed to create survey")}finally{this.loading=!1}},async updateSurvey(e,r){this.loading=!0,this.error=null;try{const{data:t}=await u.mutate({mutation:y,variables:{id:e,input:r}}),s=t?.updateSurvey;if(s){const i=this.surveys.findIndex(n=>n.id===e);i!==-1&&(this.surveys=[...this.surveys.slice(0,i),s,...this.surveys.slice(i+1)]),this.currentSurvey?.id===e&&(this.currentSurvey=s,s.currentVersion!==this.activeSurveyVersion&&(this.activeSurveyVersion=s.currentVersion||1)),this.handleSuccess(`Survey "${s.name}" updated successfully`)}return s}catch(t){return this.handleError(t,"Failed to update survey")}finally{this.loading=!1}},async deleteSurvey(e,r){this.loading=!0,this.error=null;try{const{data:t}=await u.mutate({mutation:A,variables:{id:e,force:r}}),s=t?.deleteSurvey;return s?.success&&(this.surveys=this.surveys.filter(i=>i.id!==e),this.totalCount-=s.deletedCount||1,this.currentSurvey?.id===e&&(this.currentSurvey=null,this.activeSurveyVersion=-1),this.handleSuccess("Survey deleted successfully")),s}catch(t){return this.handleError(t,"Failed to delete survey")}finally{this.loading=!1}},async cloneSurvey(e,r,t){this.loading=!0,this.error=null;try{const{data:s}=await u.mutate({mutation:V,variables:{id:e,name:r,includeResponses:t}}),i=s?.cloneSurvey;return i&&(this.surveys=[i,...this.surveys],this.totalCount++,this.handleSuccess(`Survey "${i.name}" cloned successfully`),this.currentSurvey=i,this.activeSurveyVersion=i.currentVersion||1),i}catch(s){return this.handleError(s,"Failed to clone survey")}finally{this.loading=!1}},async createNewVersion(e,r,t,s){this.loading=!0,this.error=null;try{const{data:i}=await u.mutate({mutation:b,variables:{id:e,input:{questions:r,changelog:t,publish:s}}}),n=i?.createNewVersion;if(n){const c=this.surveys.findIndex(a=>a.id===e);c!==-1&&(this.surveys=[...this.surveys.slice(0,c),n,...this.surveys.slice(c+1)]),this.currentSurvey?.id===e&&(this.currentSurvey=n,this.activeSurveyVersion=n.currentVersion||1),this.handleSuccess(`New version ${n.currentVersion} created`)}return n}catch(i){return this.handleError(i,"Failed to create new version")}finally{this.loading=!1}},async archiveSurvey(e){this.loading=!0,this.error=null;try{const{data:r}=await u.mutate({mutation:C,variables:{id:e}}),t=r?.archiveSurvey;if(t){const s=this.surveys.findIndex(i=>i.id===e);s!==-1&&(this.surveys=[...this.surveys.slice(0,s),t,...this.surveys.slice(s+1)]),this.currentSurvey?.id===e&&(this.currentSurvey=t),this.handleSuccess(`Survey "${t.name}" archived`)}return t}catch(r){return this.handleError(r,"Failed to archive survey")}finally{this.loading=!1}},async restoreSurvey(e){this.loading=!0,this.error=null;try{const{data:r}=await u.mutate({mutation:T,variables:{id:e}}),t=r?.restoreSurvey;if(t){const s=this.surveys.findIndex(i=>i.id===e);s!==-1&&(this.surveys=[...this.surveys.slice(0,s),t,...this.surveys.slice(s+1)]),this.currentSurvey?.id===e&&(this.currentSurvey=t),this.handleSuccess(`Survey "${t.name}" restored`)}return t}catch(r){return this.handleError(r,"Failed to restore survey")}finally{this.loading=!1}},setActiveSurveyVersion(e){this.activeSurveyVersion=e,e===-1?this.currentSurvey&&console.log("Setting active version to -1 (new survey mode)"):this.currentSurvey&&(this.currentSurvey.versions?.some(t=>t.version===e)||(console.warn(`Version ${e} not found in survey ${this.currentSurvey.id}`),this.activeSurveyVersion=-1))},async loadSurveyVersion(e){if(!this.currentSurvey)throw new Error("No survey loaded");const r=this.currentSurvey.versions?.find(t=>t.version===e);if(r)return this.setActiveSurveyVersion(e),r;this.loading=!0;try{const t=await this.fetchSurveyById(this.currentSurvey.id);if(t){const s=t.versions?.find(i=>i.version===e);if(s)return this.setActiveSurveyVersion(e),s;throw new Error(`Version ${e} not found`)}}catch(t){throw console.error("Failed to load survey version:",t),t}finally{this.loading=!1}},getVersionQuestions(e){return this.currentSurvey?this.currentSurvey.versions?.find(t=>t.version===e)?.questions||[]:[]},getCurrentVersionQuestions(){if(!this.currentSurvey)return[];if(this.activeSurveyVersion===-1)return[];const e=this.getActiveVersionQuestions;return e.length>0?e:this.currentSurvey.versions?.find(t=>t.version===this.currentSurvey?.currentVersion)?.questions||[]},resetToNewSurvey(){this.activeSurveyVersion=-1},getNextVersionNumber(){return this.currentSurvey?Math.max(0,...this.currentSurvey.versions?.map(r=>r.version)||[0])+1:1},versionExists(e){return this.currentSurvey&&this.currentSurvey.versions?.some(r=>r.version===e)||!1},getSortedVersions(){return this.currentSurvey?[...this.currentSurvey.versions].sort((e,r)=>r.version-e.version):[]},async deployVersion(e,r,t){this.loading=!0,this.error=null;try{if(!this.versionExists(r))throw new Error(`Version ${r} does not exist`);const{data:s}=await u.mutate({mutation:y,variables:{id:e,input:{status:"DEPLOYED",...t}}}),i=s?.updateSurvey;if(i){this.currentSurvey=i;const n=i.versions?.find(c=>c.version===r);n&&(n.deployedToKobo=!0),this.handleSuccess(`Version ${r} deployed successfully`)}return i}catch(s){return this.handleError(s,"Failed to deploy version")}finally{this.loading=!1}}}});export{h as S,S as a,Q as u};
//# sourceMappingURL=survey-90646171.js.map
