import{_ as n}from"./index-71663f0d.js";import{T as o,Q as r,R as c,S as a,n as s}from"./vendor-vue-86b105d4.js";import"./vendor-graphql-e4435811.js";import"./vendor-ui-0c00d9d8.js";const _={};function p(m,i){const e=o("RouterView"),t=o("v-app");return r(),c(t,null,{default:a(()=>[s(e)]),_:1})}const x=n(_,[["render",p]]);export{x as default};
//# sourceMappingURL=HomeLayout-3089bf29.js.map
