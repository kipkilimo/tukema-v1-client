import{M as U,h as f,k as y}from"./vendor-vue-86b105d4.js";import{c as S}from"./vendor-graphql-e4435811.js";import{a as Y,c as P}from"./index-71663f0d.js";import{P as b}from"./plans-ad5fc123.js";const x=300,u={CREATE_SURVEY:"CREATE_SURVEY",UPLOAD_XLSFORM:"UPLOAD_XLSFORM",EDIT_SURVEY:"EDIT_SURVEY",VIEW_SURVEY:"VIEW_SURVEY",CONFIRM_DELETE:"CONFIRM_DELETE",SEARCH_RESULTS:"SEARCH_RESULTS"},le=U("dialog",{state:()=>({activeDialogs:{}}),actions:{open(e,s){const p=this.activeDialogs[e];p?._timer&&clearTimeout(p._timer),this.activeDialogs[e]={visible:!0,payload:s??null}},close(e){const s=this.activeDialogs[e];s&&(s.visible=!1,s._timer=window.setTimeout(()=>{delete this.activeDialogs[e]},x))},toggle(e,s){this.isOpen(e)?this.close(e):this.open(e,s)},isOpen(e){return!!this.activeDialogs[e]?.visible},getPayload(e){return this.activeDialogs[e]?.payload??null},closeAll(){Object.keys(this.activeDialogs).forEach(e=>{this.close(e)})},openCreateSurvey(e){this.open(u.CREATE_SURVEY,e)},closeCreateSurvey(){this.close(u.CREATE_SURVEY)},openUploadXLSForm(e){this.open(u.UPLOAD_XLSFORM,{survey:e})},closeUploadXLSForm(){this.close(u.UPLOAD_XLSFORM)},openEditSurvey(e){this.open(u.EDIT_SURVEY,{survey:e})},closeEditSurvey(){this.close(u.EDIT_SURVEY)},openViewSurvey(e){this.open(u.VIEW_SURVEY,{survey:e})},closeViewSurvey(){this.close(u.VIEW_SURVEY)},openConfirmDelete(e){this.open(u.CONFIRM_DELETE,{survey:e})},closeConfirmDelete(){this.close(u.CONFIRM_DELETE)},openSearchResults(e){this.open(u.SEARCH_RESULTS,{query:e})},closeSearchResults(){this.close(u.SEARCH_RESULTS)}}}),R=b.starter,W=S`
  query MyCurrentPayment {
    myCurrentPayment {
      id
      plan
      status
      amount
      currency
      subscriptionId
      paymentDate
      planExpiry
    }
  }
`,q=S`
  query MyPayments {
    myPayments {
      id
      plan
      amount
      currency
      paymentMethod
      status
      paymentDate
    }
  }
`,B=S`
  mutation MakePaypalPayment(
    $plan: String!
    $amount: Float!
    $currency: String
    $successUrl: String
    $selectedMonths: Int
    $cancelUrl: String
  ) {
    makePaypalPayment(
      plan: $plan
      amount: $amount
      currency: $currency
      successUrl: $successUrl
      cancelUrl: $cancelUrl
      selectedMonths: $selectedMonths
    ) {
      success
      message
      payment {
        id
        plan
        amount
        currency
        status
        paymentDate
        planExpiry
      }
      redirectUrl
      subscriptionId
      paymentIntentId
      pending
    }
  }
`,X=S`
  mutation MakeMpesaPayment(
    $plan: PlanType!
    $phoneNumber: String!
    $amount: Float!
    $currency: String
    $selectedMonths: Int
  ) {
    makeMpesaPayment(
      plan: $plan
      phoneNumber: $phoneNumber
      amount: $amount
      currency: $currency
      selectedMonths: $selectedMonths
    ) {
      success
      message
      checkoutId
      paymentId
      pending
      sseUrl
    }
  }
`,H=S`
  mutation CancelSubscription($subscriptionId: String!) {
    cancelSubscription(subscriptionId: $subscriptionId) {
      success
      message
    }
  }
`,z=S`
  query CheckPayment($paymentId: String!) {
    checkPayment(paymentId: $paymentId) {
      status
      completed
      payment {
        id
        plan
        amount
        currency
        status
        paymentDate
        planExpiry
      }
    }
  }
`,re=U("billing",()=>{const e=f(null),s=f([]),p=f(R),n=f(!1),l=f(null),A=f(12),r=Y(),I=y(()=>Object.values(b)),T=y(()=>e.value?e.value.status==="COMPLETED"&&(!e.value.planExpiry||new Date(e.value.planExpiry)>new Date):!1),D=y(()=>e.value?.plan??R.id),_=y(()=>b[D.value.toLowerCase()]??R),C=y(()=>p.value),L=y(()=>s.value.reduce((t,a)=>t+a.amount,0)),$=y(()=>{if(!e.value?.planExpiry)return null;const t=new Date,a=new Date(e.value.planExpiry);return Math.max(0,Math.ceil((a.getTime()-t.getTime())/(1e3*60*60*24)))}),F=y(()=>s.value.filter(t=>t.paymentMethod==="MPESA")),k=y(()=>s.value.filter(t=>t.paymentMethod==="PAYPAL")),m=(t,a="Something went wrong")=>{console.error("[BillingStore]",t);const c=t?.graphQLErrors?.[0]?.message||t?.message||a;l.value=c,r.show({message:c,type:"error"})},d=t=>{r.show({message:t,type:"success"})},N=()=>{l.value=null},O=t=>{const a=b[t];a&&(p.value=a,r.show({message:`Selected ${a.name} plan`,type:"info"}))},g=async()=>{n.value=!0,l.value=null;try{const{data:t}=await P.query({query:W,fetchPolicy:"network-only"});return e.value=t?.myCurrentPayment||null,e.value&&d(`Loaded subscription: ${e.value.plan}`),e.value}catch(t){return m(t,"Failed to load subscription"),null}finally{n.value=!1}},w=async()=>{n.value=!0,l.value=null;try{const{data:t}=await P.query({query:q,fetchPolicy:"network-only"});return s.value=t?.myPayments||[],s.value.length>0&&d(`Loaded ${s.value.length} payments`),s.value}catch(t){return m(t,"Failed to load payments"),[]}finally{n.value=!1}};return{subscription:e,payments:s,selectedPlan:p,loading:n,error:l,selectedMonths:A,availablePlans:I,hasActiveSubscription:T,currentPlan:D,currentPlanDetails:_,selectedPlanDetails:C,totalSpent:L,daysUntilExpiry:$,mpesaPayments:F,paypalPayments:k,selectPlan:O,fetchSubscription:g,fetchPayments:w,payWithPaypal:async(t,a,c)=>{n.value=!0,l.value=null;try{const h=c?.plan||"STARTER",o=parseFloat("14"),M=parseFloat("1950"),E=parseFloat({}.VITE_EXCHANGE_RATE||"131");let v;switch(h.toUpperCase()){case"STARTER":v=o*10;break;case"PROFESSIONAL":v=o*50;break;case"ENTERPRISE":v=M*100;break;default:v=o*10}v=Math.round(v*100)/100;const{data:V}=await P.mutate({mutation:B,variables:{plan:h.toUpperCase(),amount:v,currency:c?.currency||"USD",successUrl:t||window.location.href,cancelUrl:a||window.location.href}}),i=V?.makePaypalPayment;return i?.success?(i.payment&&(s.value=[i.payment,...s.value],e.value={id:i.subscriptionId,plan:i.payment.plan,status:i.payment.status,startDate:i.payment.paymentDate,expiryDate:i.payment.planExpiry,amount:i.payment.amount}),r.show({message:i.message||"PayPal payment initiated",type:"success",timeout:3e3}),i?.redirectUrl&&(r.show({message:"Redirecting to PayPal...",type:"info",timeout:3e3}),window.location.href=i.redirectUrl)):r.show({message:i?.message||"PayPal payment failed",type:"error"}),i}catch(h){return m(h,"Failed to create PayPal payment"),{success:!1,message:l.value||"Payment failed"}}finally{n.value=!1}},payWithMpesa:async(t,a,c)=>{n.value=!0,l.value=null;try{const h=a||p.value.price;let o=t.replace(/\s/g,"");o.startsWith("+")&&(o=o.substring(1)),o.startsWith("0")&&(o=`254${o.substring(1)}`),o.startsWith("254")||(o=`254${o}`);const{data:M}=await P.mutate({mutation:X,variables:{plan:p.value.id.toUpperCase(),phoneNumber:o,amount:h,currency:"KES",selectedMonths:c||1}}),E=M?.makeMpesaPayment;return E?.success?(d(E.message||"M-Pesa payment initiated. Check your phone for STK push."),r.show({message:"Please check your phone and enter your M-Pesa PIN to complete payment.",type:"info",timeout:8e3}),E.sseUrl&&console.log("[M-Pesa] SSE URL:",E.sseUrl)):r.show({message:E?.message||"M-Pesa payment failed",type:"error",timeout:5e3}),E}catch(h){return m(h,"Failed to create M-Pesa payment"),{success:!1,message:l.value||"Payment failed"}}finally{n.value=!1}},checkPaymentStatus:async t=>{n.value=!0,l.value=null;try{const{data:a}=await P.query({query:z,variables:{paymentId:t},fetchPolicy:"network-only"}),c=a?.checkPayment;return c&&(c.completed?(d("Payment completed successfully!"),await Promise.all([g(),w()])):c.status==="FAILED"?r.show({message:"Payment failed. Please try again.",type:"error"}):r.show({message:`Payment is ${c.status.toLowerCase()}. Please wait...`,type:"info"})),c}catch(a){return m(a,"Failed to check payment status"),null}finally{n.value=!1}},cancelSubscription:async()=>{if(!e.value?.subscriptionId){const t="No active subscription found";throw l.value=t,r.show({message:t,type:"error"}),new Error(t)}n.value=!0,l.value=null;try{const{data:t}=await P.mutate({mutation:H,variables:{subscriptionId:e.value.subscriptionId}}),a=t?.cancelSubscription;return a?.success?(d(a.message||"Subscription cancelled successfully"),await g()):r.show({message:a?.message||"Failed to cancel subscription",type:"error"}),a}catch(t){throw m(t,"Failed to cancel subscription"),t}finally{n.value=!1}},refreshBillingData:async()=>{n.value=!0,l.value=null;try{await Promise.all([g(),w()]),d("Billing data refreshed")}catch(t){m(t,"Failed to refresh billing data")}finally{n.value=!1}},initialize:async()=>{n.value=!0,l.value=null;try{await Promise.all([g(),w()]),e.value?d("Billing information loaded"):r.show({message:"No active subscription found",type:"info"})}catch(t){m(t,"Failed to initialize billing")}finally{n.value=!1}},clearError:N,reset:()=>{e.value=null,s.value=[],p.value=R,l.value=null,r.show({message:"Billing store reset",type:"info"})}}});export{u as D,le as a,re as u};
//# sourceMappingURL=billing-18e6d22d.js.map
