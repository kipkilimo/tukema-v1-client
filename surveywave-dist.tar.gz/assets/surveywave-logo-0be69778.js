const o="/assets/surveywave-logo-fdf551c8.png";export{o as l};
//# sourceMappingURL=surveywave-logo-0be69778.js.map
